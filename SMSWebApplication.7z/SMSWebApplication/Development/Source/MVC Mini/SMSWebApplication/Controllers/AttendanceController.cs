﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SchoolManagementSystem.Models;

namespace SchoolManagementSystem.Controllers
{
    public class AttendanceController : Controller
    {
        Entities dbContext = new Entities();
        // GET: Attendance
        public ActionResult Index()
        {
            return View();
        }

        // GET: Attendance/Details/5
        //public ActionResult Details(int id)
        //{
        //    return View();
        //}
        [HttpGet]
        public ActionResult ShowAllAttendance()
        {
            var users = from a in dbContext.Attendances
                        where a.Date == DateTime.Today
                        select a;
           // IEnumerable<Attendance> users = dbContext.Attendances.ToList();
            return View(users);
        }
        // GET: Attendance/Create
        public ActionResult Create()
        {
            ViewBag.Student_id = new SelectList(dbContext.Students, "Student_Id", "Student_Name");
            return View();
        }

        // POST: Attendance/Create
        [HttpPost]
        public ActionResult Create(Attendance attendance)
        {
            try
            {

                if (ModelState.IsValid)
                {
                    dbContext.Attendances.Add(attendance);
                    dbContext.SaveChanges();
                }


                else
                {
                    var query = from state in ModelState.Values
                                from error in state.Errors
                                select error.ErrorMessage;

                    ViewData["errorMsg"] = query.ToList();

                    return View();
                }
                return RedirectToAction("ShowAllAttendance");
            }
            catch (Exception ex)
            {
                if (ex.InnerException.InnerException.Message.Contains("UNIQUE KEY constrain"))
                    ViewData["errorMsg"] = new List<string>() { "Attendance already exists.", " " };
                else
                    ViewData["errorMsg"] = new List<string>() { ex.Message, " " };
                return View();
            }
        }

        // GET: Attendance/Edit/5
        public ActionResult Edit(int id)
        {
            Attendance attendance = new Attendance();
            var result = (from u in dbContext.Attendances
                          where u.Attendance_Id == id
                          select u).SingleOrDefault();

            return View(result);
        }

        // POST: Attendance/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            Attendance user = dbContext.Attendances.Single(u => u.Attendance_Id == id);
            try
            {
                if (ModelState == null)
                {
                    ViewData["errorMsg"] = new List<string>() { "Model is null", " " };
                }
                if (ModelState.IsValid)
                {
                    //user.Users_id = Convert.ToInt32(collection["Users_id"]);
                    user.Date = Convert.ToDateTime(collection["Date"]);
                    user.Attended = collection["Attended"];
                    user.Student_id = Convert.ToInt32(collection["Student_id"]);
                    dbContext.SaveChanges();
                }

                else
                {
                    var query = from state in ModelState.Values
                                from error in state.Errors
                                select error.ErrorMessage;

                    ViewData["errorMsg"] = query.ToList();

                    return View();
                }

                return RedirectToAction("ShowAllAttendance", user);
            }

            catch (DbEntityValidationException ex)
            {
                var query = from entityValidationErrors in ex.EntityValidationErrors
                            from validationError in entityValidationErrors.ValidationErrors
                            select validationError.ErrorMessage;
                ViewData["errorMsg"] = query.ToList();
                return View(user);

            }
        }

        // GET: Attendance/Delete/5
        public ActionResult Delete(int id)
        {
            Attendance attendance = dbContext.Attendances.Single(u => u.Attendance_Id == id);
            return View(attendance);
        }

        // POST: Attendance/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                Attendance attendance = dbContext.Attendances.Single(u => u.Attendance_Id == id);
                dbContext.Attendances.Remove(attendance);
                dbContext.SaveChanges();
                return RedirectToAction("ShowAllAttendance");
            }
            catch
            {
                return View();
            }
        }
    }
}