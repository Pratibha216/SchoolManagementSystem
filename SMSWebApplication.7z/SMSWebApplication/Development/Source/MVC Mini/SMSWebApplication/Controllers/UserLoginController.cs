﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SchoolManagementSystem.Models;
namespace SchoolManagementSystem.Controllers
{
    public class UserLoginController : Controller
    {

        // GET: UserLogin
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Authorize(SchoolManagementSystem.Models.User user)
        {
            using (Entities db = new Entities())
            {

                var userDetails = db.Users.Where(x => x.User_Name == user.User_Name && x.Password == user.Password).FirstOrDefault();
                if (userDetails == null)
                {
                    user.LoginError = "Invalid Username or Password.";
                    return View("Index", user);
                }
                else
                {
                   
                    if (userDetails.Role == "Admin")
                    {
                        Session["UserNAme"] = userDetails.User_Name;
                        return RedirectToAction("Index", "Teachers");
                    }
                    else if (userDetails.Role == "Teacher")
                    {
                        Session["UserNAme"] = userDetails.User_Name;
                        return RedirectToAction("ShowAllAttendance", "Attendance");
                    }
                    else if (userDetails.Role == "Cashier")
                    {
                        Session["UserNAme"] = userDetails.User_Name;
                        return RedirectToAction("Index", "Fees");
                    }
                    else
                    {
                        user.LoginError = "Invalid User Role";
                        return View("Index", user);
                    }
                }
            }
        }
        public ActionResult LogOut()
        {
            Session.Clear();
            Session.Abandon();
            Session.RemoveAll();

            System.Web.Security.FormsAuthentication.SignOut();


            this.Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1));
            this.Response.Cache.SetCacheability(HttpCacheability.NoCache);
            this.Response.Cache.SetNoStore();
            return RedirectToAction("Index", "UserLogin");

        }
    }
}