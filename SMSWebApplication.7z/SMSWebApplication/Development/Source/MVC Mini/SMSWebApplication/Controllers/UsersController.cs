﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SchoolManagementSystem.Models;

namespace SchoolManagementSystem.Controllers
{
    public class UserController : Controller
    {
        Entities dbContext = new Entities();

        public ActionResult Index()
        {
            IEnumerable<User> users = dbContext.Users.ToList();
            return View(users);
        }

        [HttpGet]
        public ActionResult ShowAllUsers()
        {
            IEnumerable<User> users = dbContext.Users.ToList();
            return View(users);
        }

        //public ActionResult ShowDetails(int id)
        //{
        //    User user = dbContext.Users.Single(u => u.Users_id == id);
        //    return View(user);
        //}

        [HttpGet]
        public ActionResult CreateNewUser()
        {
            return View();
        }

        [HttpPost]
        public ActionResult CreateNewUser(User user)
        {
            try
            {

                if (ModelState.IsValid)
                {
                    dbContext.Users.Add(user);
                    dbContext.SaveChanges();
                }

                else
                {
                    var query = from state in ModelState.Values
                                from error in state.Errors
                                select error.ErrorMessage;

                    ViewData["errorMsg"] = query.ToList();

                    return View();
                }
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                if (ex.InnerException.InnerException.Message.Contains("UNIQUE KEY constrain"))
                    ViewData["errorMsg"] = new List<string>() { "User Name already exists.", " " };
                else
                    ViewData["errorMsg"] = new List<string>() { ex.Message, " " };
                return View();
            }
        }

        [HttpGet]
        public ActionResult EditUser(int id)
        {
            User user = new User();
            var result = (from u in dbContext.Users
                          where u.Users_id == id
                          select u).SingleOrDefault();
            if (result != null)
            {
                return View(result);
            }
            else
            {
                return HttpNotFound();
            }

        }

        [HttpPost]
        public ActionResult EditUser(int id, FormCollection collection)
        {
            User user = dbContext.Users.Single(u => u.Users_id == id);
            try
            {
                if (ModelState == null)
                {
                    ViewData["errorMsg"] = new List<string>() { "Model is null", " " };
                }
                if (ModelState.IsValid)
                {
                    //user.Users_id = Convert.ToInt32(collection["Users_id"]);
                    user.Password = collection["Password"];
                    user.Role = collection["Role"];
                    user.User_Name = collection["User_Name"];
                    dbContext.SaveChanges();
                }

                else
                {
                    var query = from state in ModelState.Values
                                from error in state.Errors
                                select error.ErrorMessage;

                    ViewData["errorMsg"] = query.ToList();

                    return View();
                }

                return RedirectToAction("Index", user);
            }

            catch (DbEntityValidationException ex)
            {
                var query = from entityValidationErrors in ex.EntityValidationErrors
                            from validationError in entityValidationErrors.ValidationErrors
                            select validationError.ErrorMessage;
                ViewData["errorMsg"] = query.ToList();
                return View(user);

            }
        }

        [HttpGet]
        public ActionResult DeleteUser(int id)
        {
            User user = dbContext.Users.Single(u => u.Users_id == id);
            if (user != null)
            {
                return View(user);
            }
            else
            {
                return HttpNotFound();
            }
        }


        [HttpPost]
        public ActionResult DeleteUser(int id, FormCollection collection)
        {
            try
            {
                User user = dbContext.Users.Single(u => u.Users_id == id);
                dbContext.Users.Remove(user);
                dbContext.SaveChanges();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}